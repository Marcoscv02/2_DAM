package UD3.editor_texto;

public class App {
    public static void main(String[] args) {
        Graphics graficos= new Graphics();
        graficos.getGraphics();
    }
}
